# Enemy Design

Created: October 4, 2026 12:19 AM

# 👾 CodeVaders — Enemy / Bug Specification

> **Purpose:** This document defines the gameplay behavior of every enemy/bug in CodeVaders.
> 
> 
> Implement enemies **one type at a time**, starting with **Common Bug**.
> 
> Do not implement future enemy types until their phase begins.
> 

---

## Enemy Design Principle

Every enemy should have:

**Visual Identity → Movement Pattern → Attack Pattern → HP → Player Counterplay → Death Behavior**

Enemies should not be simple reskins of the same behavior.

---

# 🐛 1. Common Bug

### Role

Basic / introductory enemy.

### HP

`1`

### Movement

```
SPAWN
  ↓
WAIT
  ↓
DIVE TOWARD PLAYER
  ↓
EXIT / COLLIDE
```

- Appears in the upper portion of the playfield.
- Initially waits in position.
- After a short configurable delay, dives toward the player.
- Direction should be calculated toward the player's position when the dive begins.
- Uses `deltaTime`.
- Should not behave like a continuously homing missile.

### Attack

**No projectile attack.**

Its attack is the dive itself.

### Player Interaction

- Player bullet → destroyed immediately.
- Enemy collision → damages player.
- After collision, enemy should be removed.
- Existing player invulnerability logic should prevent repeated damage.

### Death

```
1 HIT
 ↓
EXPLOSION
 ↓
REMOVE
```

- Small explosion.
- Small particle effect.
- Score awarded through existing score system.

---

# 💀 2. Critical Bug

### Role

Stronger standard enemy.

### HP

`2`

### Movement

- Appears in the enemy formation.
- Remains around its assigned position.
- Can have small controlled movement/hovering.
- Does not perform the aggressive Common Bug dive.

### Attack

**Targeted projectile.**

```
              PLAYER
                ↑
                │
                │
             BULLET
                │
                ▼
          CRITICAL BUG
```

- Fires a projectile toward the player's current position.
- Configurable fire rate.
- Projectile uses the generic enemy projectile system.

### Player Interaction

- Requires **2 hits** to destroy.
- Enemy/projectile can damage player.

### Death

```
2 HITS
  ↓
EXPLOSION
  ↓
REMOVE
```

Medium explosion.

---

# ☠️ 3. DDoS Bug

### Role

Projectile-pattern enemy that creates multiple threats.

### HP

`TBD`

> HP is not currently specified. Keep this configurable rather than assuming a value.
> 

### Movement

- Uses formation-style movement.
- Movement itself is not the primary threat.
- Main threat comes from projectile splitting.

### Attack

Fires **one parent projectile**.

```
             BUG
              │
              ▼
             ●
              │
            SPLIT
          ↙   ↓   ↘
         ●    ●    ●
```

The parent projectile:

1. Travels toward the player.
2. Reaches its split condition.
3. Is destroyed.
4. Creates **3 child projectiles**.
5. The resulting projectiles travel in different vertical directions.

### Important

The 3 resulting projectiles are **independent projectiles** after splitting.

Do not make the original projectile continue existing after the split.

### Player Interaction

- Avoid the parent projectile.
- Avoid the three resulting projectiles.
- Destroy the DDoS Bug through normal player bullets.

---

# 🪱 4. Worm

### Role

Movement-disruption enemy.

### HP

`TBD`

### Entry

Worms enter from the **left or right side** of the screen.

```
← 🪱
```

or

```
🪱 →
```

### Movement

After entering:

- Moves using random/unpredictable motion.
- Should feel different from formation enemies.
- Must remain within reasonable gameplay boundaries.
- Random movement should still be controllable/predictable enough for gameplay.

Example:

```
LEFT
 ↓
 ↗
   →
 ↘
   ↑
     →
RIGHT
```

### Attack

No specific projectile attack has been defined.

The Worm's primary threat is its unpredictable movement.

### Player Interaction

- Player bullets damage the Worm.
- Collision with player damages player according to the existing collision system.

---

# 🦠 5. Virus

### Role

High-value / high-threat enemy.

### HP

`4`

### Movement

- Standard controlled enemy movement.
- Should be more threatening than basic enemies.
- Movement pattern can use the existing formation system.

### Attack

**Fast bullets.**

Compared with normal enemy projectiles:

- Higher firing frequency.
- Faster projectile velocity.

```
        🦠
       ↓ ↓ ↓
      • • •
       ↓ ↓
     PLAYER
```

### Player Interaction

Requires **4 hits**.

```
HIT 1 → 3 HP
HIT 2 → 2 HP
HIT 3 → 1 HP
HIT 4 → DESTROY
```

### Special Death Behavior

The Virus does **not simply disappear**.

On destruction:

```
             VIRUS
               ↓
             💥
          /    |    \
         🐛    🐛    🐛
```

- Trigger explosion.
- Spawn **3 Common Bugs**.
- Spawned Common Bugs behave exactly like normal Common Bugs.
- They should enter the normal enemy lifecycle.
- Prevent infinite recursive spawning.

**Important:** Common Bugs spawned from Virus should **not spawn additional enemies**.

---

# 🔍 6. Scan Bug

### Role

Area-control / positioning enemy.

### HP

`TBD`

### Movement

```
SPAWN
  ↓
MOVE TO POSITION
  ↓
STOP
```

- Moves to a designated position.
- Once positioned, stops normal movement.

### Attack

Instead of firing a normal projectile, it performs a **scan attack**.

```
        🔍
         │
         │
   ┌─────────────┐
   │   SCAN AREA │
   │      🚀     │
   └─────────────┘
```

Attack sequence:

```
POSITION
   ↓
CHARGE / TELEGRAPH
   ↓
SCAN AREA
   ↓
END SCAN
   ↓
COOLDOWN
```

### Player Counterplay

The player should:

> **Leave the scan area before the scan activates.**
> 

The scan must have a visible warning/telegraph before becoming active.

### Important

The exact damage/penalty for remaining inside the scan area is **not yet specified**. Keep it configurable.

---

# 📊 Enemy Summary

| Enemy | HP | Movement | Attack | Special |
| --- | --- | --- | --- | --- |
| 🐛 Common Bug | 1 | Wait → Dive | None | Basic enemy |
| 💀 Critical Bug | 2 | Formation | Targeted bullet | Stronger attacker |
| ☠️ DDoS Bug | TBD | Formation | Split projectile | 1 → 3 bullets |
| 🪱 Worm | TBD | Random / side entry | None specified | Unpredictable movement |
| 🦠 Virus | 4 | Controlled | Fast bullets | Spawns 3 Common Bugs |
| 🔍 Scan Bug | TBD | Move → Position | Scan area | Area denial |

---

# 🧩 Implementation Requirements

All enemies should eventually use a common architecture:

```
Enemy
 ├── position
 ├── velocity
 ├── hp
 ├── state
 ├── update(dt)
 ├── takeDamage()
 ├── attack()
 ├── destroy()
 └── explode()
```

Use an `EnemyRegistry` so adding future enemies does not require rewriting the core game engine.

```
EnemyRegistry
├── CommonBug
├── CriticalBug
├── DDoSBug
├── Worm
├── Virus
└── ScanBug
```