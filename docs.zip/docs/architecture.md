# CodeVaders Architecture

## Overview
CodeVaders is an infinite, retro-futuristic arcade space shooter built on the MERN stack.

### Tech Stack
- **Frontend**: React (Vite)
- **Game Engine**: HTML5 Canvas 2D
- **Styling**: TailwindCSS + Custom CSS
- **Backend**: Node.js + Express
- **Database**: MongoDB + Mongoose

## Directory Structure
- `/client`: Frontend React application.
  - `/src/components`: Reusable UI components.
  - `/src/game`: The core game engine and entity logic.
  - `/src/screens`: Top-level screens (e.g., PlayScreen).
  - `/src/styles`: Custom CSS styles including retro arcade themes.
- `/server`: Node.js backend for authentication and leaderboards.
- `/docs`: Project documentation for game mechanics and design.
