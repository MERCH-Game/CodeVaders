# Game Engine Documentation

## Core Loop
The core of CodeVaders runs inside `GameEngine.js`, utilizing an HTML5 Canvas for rendering.
It operates on a delta-time (`dt`) physics loop to ensure frame-rate independence.

### Key Components
1. **Engine Setup**:
   The engine initializes with a reference to the `canvas` element and optional callbacks for events like player hits, power-up collections, and firing lasers.

2. **Loop Method**:
   Uses `requestAnimationFrame` to manage the game tick. The update logic computes the delta time (`dt`), scaling all game physics by this value. Max `dt` is capped at 0.1s to handle tab-switching or lag spikes gracefully.

3. **Update Phase**:
   - Updates timers for power-ups (e.g., `cppPowerUpTimer`, `tripleShotTimer`).
   - Invokes the `update(dt)` method on `EnemySpawner` and `PowerUpSpawner`.
   - Iterates through all active entities, calling their `update(dt)` methods. Destroyed entities (`isDead === true`) are removed from the array.

4. **Collision Detection**:
   Uses Simple AABB (Axis-Aligned Bounding Box) collision logic. Handled in `handleCollisions()`:
   - Player vs Enemy
   - Player vs PowerUpDrops
   - PlayerLasers vs Enemies (clears enemy bullets as well)
   - PlayerBullets vs Enemies

5. **Render Phase**:
   Clears the canvas context and calls `render(ctx)` on all active entities.
